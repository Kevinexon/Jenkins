package pl.wsb.mvc.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pl.wsb.mvc.model.Student;
import pl.wsb.mvc.repository.StudentRepository;

import java.util.List;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public List<Student> listAllStudents() {
        return studentRepository.findAll();
    }

    public Student findById(Long id) {
    return studentRepository.findById(id).get();
    }

    public void save(Student student) {
        studentRepository.save(student);
    }
}
