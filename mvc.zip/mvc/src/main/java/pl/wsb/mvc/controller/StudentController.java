package pl.wsb.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import pl.wsb.mvc.model.Student;
import pl.wsb.mvc.services.StudentService;

import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping("/all")
    public List<Student> getStudents(){
    return studentService.listAllStudents();
    }

    @GetMapping("/")
    public String listStudents(Model model){
        List<Student> students = studentService.listAllStudents();
        model.addAttribute("studentList" ,students);
        return "index";
    }


    @GetMapping("/get/{id}")
    public Student getOne(@PathVariable Long id){
    return studentService.findById(id);
    }

    @RequestMapping("/new")
    public String newStudent(Model model){
        Student student = new Student();
        model.addAttribute(student);
        return "new_student";
    }

    @RequestMapping(value = "save", method = RequestMethod.POST)
    public String saveStudent(@ModelAttribute("student") Student student){
        studentService.save(student);
        return "redirect:/";
    }
}
