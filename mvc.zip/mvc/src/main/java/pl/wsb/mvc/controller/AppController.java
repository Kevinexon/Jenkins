package pl.wsb.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.time.LocalDate;

@Controller
public class AppController {
    @RequestMapping("/")
    public String goHome(Model model){
        String witaj = "Dane z kontrolera, aeiou";
        model.addAttribute("witaj", witaj);
        model.addAttribute("localDate", LocalDate.now());
        String langusta = "Langusta naturalnie żywi się owocami morza, choć gdyby mogła, jadłaby dżem";
        model.addAttribute("langusta", langusta);
        return("index");
    }
}
